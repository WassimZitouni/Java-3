import javax.swing.JOptionPane;

public class java3parta
 {
    public static void main(String[] args)
     {
        // Declare the variable
        String bookTitle;
        double bookPrice;
        double total = 0.0;
        int bookCount = 0;
        double discountRate = 0.0;
        // Declare sales tax rate as a constant
        final double SALES_TAX_RATE = 0.085;
        do 
        {
            // Enter the book title 
            bookTitle = JOptionPane.showInputDialog("Enter the book title (leave blank to finish):");
            if (!bookTitle.equals("")) 
            {
                // Enter the price of the book
                bookPrice = Double.parseDouble(JOptionPane.showInputDialog("Enter the price of the book:"));
                total += bookPrice;
                // Increment the book count
                bookCount++;
                // Show title and price
                System.out.printf("Book: %-28s $%,6.2f\n", bookTitle, bookPrice);
            }
        } while (!bookTitle.equals(""));
               if (bookCount == 0) 
               {
            System.out.println("No books were ordered.");
        } else {
            // Determine the discount rate based on the number of books ordered
            if (bookCount > 7) 
            {
                discountRate = 0.15;
            } else if (bookCount >= 4) 
            {
                discountRate = 0.10;
            }
            // Find the discount, subtotal, sales tax, and amount due
            double discount = total * discountRate;
            double subtotal = total - discount;
            double salesTax = subtotal * SALES_TAX_RATE;
            double amountDue = subtotal + salesTax;
            // Compute the total, discount, subtotal, sales tax, and amount due in a formatted manner
            System.out.printf("%29s $%,6.2f\n", "Total:", total);
            System.out.printf("Discount (%2.0f%%)           -$%,6.2f\n", discountRate * 100, discount);
            System.out.printf("%29s $%,6.2f\n", "Subtotal:", subtotal);
            System.out.printf("Sales Tax (8.5%%)         +$%,6.2f\n", salesTax);
            System.out.printf("%29s $%,6.2f\n", "Amount Due:", amountDue);
        }
              System.exit(0);
    }
}