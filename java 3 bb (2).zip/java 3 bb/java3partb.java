import java.util.Scanner;

public class java3partb
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        // Declare variables for beginning balance, annual withdrawal and interest rate
        double beginningBalance, annualWithdrawal, interestRate;
        int year = 1;
        final int MAX_YEARS = 20;
        // Enter the beginning balance annual withdrawal, and interest rate
         System.out.print("Enter the beginning balance: ");
         beginningBalance = scanner.nextDouble();
         System.out.print("Enter the annual withdrawal amount: ");
              annualWithdrawal = scanner.nextDouble();
        // Enter the annual interest rate
        System.out.print("Enter the annual interest rate (as a decimal): ");
               interestRate = scanner.nextDouble();
               System.out.println("\nYear\tBeginning Balance\tWithdrawal\tEarnings\tEnding Balance");
        // Iterate each year until reaching the maximum number of years 
        while (year <= MAX_YEARS && beginningBalance > annualWithdrawal) 
        {
            // Calculate earnings and ending balance for the year
            double earnings = (beginningBalance - annualWithdrawal) * interestRate;
            double endingBalance = beginningBalance - annualWithdrawal + earnings;
                    System.out.printf("%d\t%,12.2f\t%,10.2f\t%,10.2f\t%,12.2f\n",
                    year, beginningBalance, annualWithdrawal, earnings, endingBalance);
                        beginningBalance = endingBalance;
                       year++;
        }
                scanner.close();
    }
}