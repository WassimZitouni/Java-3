import javax.swing.JOptionPane;

public class java3partc
{
    public static void main(String[] args) 
    {
        // Define the price per square yard 
        final double PRICE_PER_SQUARE_YARD = 23.85;
        // Declare variables 
        int numberOfRooms;
        double length, width, squareYards, totalSquareYards = 0, estimatedCost;
        // enter number of rooms needing flooring
        String input = JOptionPane.showInputDialog("How many rooms need flooring?");
        numberOfRooms = Integer.parseInt(input);
        for (int i = 1; i <= numberOfRooms; i++) 
        {
            // Enter the length and width of the current room
            input = JOptionPane.showInputDialog("Enter the length of Room " + i + " in feet:");
            length = Double.parseDouble(input);
            input = JOptionPane.showInputDialog("Enter the width of Room " + i + " in feet:");
            width = Double.parseDouble(input);
            // Calculate the square yards for the current room
            squareYards = (length * width) / 9;
            // Add the square yards of the current room to the total
            totalSquareYards += squareYards; 
            JOptionPane.showMessageDialog(null, String.format("Room %d: Length = %.2f ft, Width = %.2f ft, Square Feet = %.2f, Square Yards = %.2f",
                    i, length, width, (length * width), squareYards));
        }
        // Calculate the estimated cost 
        estimatedCost = totalSquareYards * PRICE_PER_SQUARE_YARD;
        // Display square yards and estimated cost
        JOptionPane.showMessageDialog(null, String.format("Total Square Yards: %.2f\nEstimated Cost: $%,.2f", totalSquareYards, estimatedCost));
        System.exit(0);
    }
}